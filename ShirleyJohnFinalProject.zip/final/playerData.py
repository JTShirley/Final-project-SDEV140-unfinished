"""
This is the code that allows for all the player's data to be stored
"""
from tkinter import *
import tkinter as tk
#The variable that will be set to various user enters, then put into a file
global string
string = ''
#Whatever the name of the file currently being modded is
global currentFile
currentFile = ''
#The name that the player puts into the name box
global playerName
playerName = ''
#The age that the player chooses from a drop-down list
global ageChoice
ageChoice = ''
#The number of players that the player likes to play with. Selected from a drop-down list
global playerChoice
playerChoice = ''
#What format the player likes to play with(online, live, or both). Selected from a drop-down list
global locationChoice
locationChoice = ''
#The file with player data that the user is retrieving
global retrivedFile
retrivedFile = ''
#The input from the user that allows the system to pull up player data
global playerRetrieval
playerRetrieval = ''
#Code to write information to the current file being modified
def writeNew():
    global string
    global currentFile
    with open(currentFile, 'a') as file:
       file.write(string+"\n")
#Code to save all received information to a file
def save():
    global playerName
    global currentFile
    global string
    string=''
    string = playerName.get()
    if string == '':
       retrivedWrite.configure(text="Please enter a name")
    else:
       currentFile="Data/"+string+".txt"
       playerData=open(currentFile,"w")
       playerData.close()
       writeName()
       writeAge()
       writeNumber()
       writePreference()
#Code to write the name of the player to the file
def writeName():
   global playerName
   global string
   string=''
   string = playerName.get()
   writeNew()
#Code to write the age of the player to the file
def writeAge():
   global ageChoice
   global string
   string=''
   string = ageChoice.get()
   writeNew()
#Code to write the number of players the player likes to play with to the file
def writeNumber():
   global playerChoice
   global string
   string=''
   string = playerChoice.get()
   writeNew()
#Code to write if the player prefers online or in person
def writePreference():
   global locationChoice
   global currentFile
   global string
   string=''
   string = locationChoice.get()
   writeNew()
#Code to check if the user has used the name of an existing file
def checkFile():
   global retrivedFile
   global retrivedWrite
   try:
       with open(retrivedFile,'r') as f:
          data1 = f.read()
          data2 = data1.splitlines()
          retrivedWrite.configure(text="Name: "+str(data2[0])+"\nAge: "+str(data2[1])+"\nPrefered Number\nof Players: "+str(data2[2])+"\nOnline or Live: "+str(data2[3]))
   except IOError:
      retrivedWrite.configure(text=("File not accessible"))
#Code to retrieve player data
def retrievePlayerData():
   global playerRetrieval
   global retrivedFile
   string = playerName.get()
   if string == '':
      retrivedWrite.configure(text=("File not accessible"))
   else:
      retrivedFile = "Data/"+string+".txt"
      checkFile()
def openPlayer():
    root2=tk.Tk()
    root2.title('Player Data')
    global retrivedWrite
    global playerName
    global locationChoice
    global nameDisplay
    global ageChoice
    global playerChoice
    global playerRetrieval
    F2=Frame(root2)
    F2.pack(
        ipadx=300,
        ipady=300,
        )
    ages=[
       "1-10",
       "11-17",
       "18-25",
       "26-30",
       "31-35",
       "36-40",
       "41-45",
       "46+"
       ]
    players=[
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10+"
       ]
    locations=[
       "online",
       "live",
       "both"
       ]
    ageChoice = StringVar(root2)
    ageChoice.set(ages[0])
    ageDisplay = OptionMenu(F2, ageChoice, *ages)
    ageDisplay.place(x=70, y=150)
    playerChoice = StringVar(root2)
    playerChoice.set(players[0])
    playerDisplay = OptionMenu(F2, playerChoice, *players)
    playerDisplay.place(x=380,y=200)
    locationChoice = StringVar(root2)
    locationChoice.set(locations[0])
    locationDisplay = OptionMenu(F2, locationChoice, *locations)
    locationDisplay.place(x=380,y=300)
    name = Label(root2,text="Name:", font=("Courier 14"))
    name.place(x=30, y=100)
    playerName = Entry(root2, width= 10)
    playerName.place(x=70,y=100)
    age = Label(root2,text="Age:", font=("Courier 14"))
    age.place(x=30, y=150)
    players = Label(root2,text="How many players do you like to play with:", font=("Courier 14"))
    players.place(x=30, y=200)
    locations = Label(root2,text="Do you prefer to play online or in person:", font=("Courier 14"))
    locations.place(x=30, y=300)
    nameDisplay=Label(root2,text="", font=("Courier 22"))
    nameDisplay.place(x=175,y=100)
    ageDisplay=Label(root2,text="", font=("Courier 22"))
    ageDisplay.place(x=175,y=150)
    variable=("one-ten")
    enter = Button(root2,padx=10,pady=10, text= "Save", command = save)
    enter.pack()
    retrieveBtn = Button(root2,padx=10,pady=10, text = "Retrieve", command = retrievePlayerData)
    retrieveBtn.pack()
    exitBtn = Button(root2,padx=10,pady=10, text = "Exit", command = root2.destroy).pack()
    title = Label(root2, text="Player Data",font=("Courier 22"))
    title.place(x=200, y=20)
    retrivedWrite = Label(root2,text="", font=("Courier 22"))
    retrivedWrite.place(x=100,y=350)
    root2.mainloop()
