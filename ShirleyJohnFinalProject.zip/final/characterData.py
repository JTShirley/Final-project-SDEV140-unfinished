"""
This module is what the player uses to create characters
"""
from tkinter import *
import tkinter as tk
#The name of the character that the user enters
global characterName
characterName = ''
#The name of the file that the character's data will be stored in
global charFile
charFile = ''
#The class of the character that the user enters
global characterClass
characterClass = ''
#The race of the character that the user enters
global characterRace
characterRace = ''
#The level of the character that the user enters
global levelChoice
levelChoice = ''
#The age of the character that the user enters
global characterAge
characterAge = ''
#The inventory slots of the character that the user enters
global inventoryInp1
inventoryInp1 = ''
global inventoryInp2
inventoryInp2 = ''
global inventoryInp3
inventoryInp3 = ''
global inventoryInp4
inventoryInp4 = ''
global inventoryInp5
inventoryInp5 = ''
global inventoryInp6
inventoryInp6 = ''
global inventoryInp7
inventoryInp7 = ''
global inventoryInp8
inventoryInp8 = ''
global inventoryInp9
inventoryInp9 = ''
#Code to create a new character
def createCharacter():
    global characterName
    global charFile
    global string
    global retrivedCharWrite
    string=''
    string = characterName.get()
    if string == '':
       retrivedCharWrite.configure(text="Please enter a name")
    else:
       charFile = str("Data/Char"+string+".txt")
       playerData=open(charFile,"w")
       playerData.close()
       writeCharName()
       writeCharAge()
       writeCharClass()
       writeCharRace()
       writeCharLevel()
       writeInventory()
#Code to write the character's name to the current file
def writeCharName():
   global characterName
   string = characterName.get()
   with open(charFile, 'a') as file:
       file.write(string+"\n")
#Code to write the character's class to the current file
def writeCharClass():
   global characterClass
   string = characterClass.get()
   if string == '':
      retrivedCharWrite.configure(text="Please enter a\nClass")
   else:
      with open(charFile, 'a') as file:
          file.write(string+"\n")
#Code to write the character's race to the current file
def writeCharRace():
   global characterRace
   string = characterRace.get()
   if string == '':
      retrivedCharWrite.configure(text="Please enter a\nRace")
   else:
      with open(charFile, 'a') as file:
          file.write(string+"\n")
#Code to write the character's level to the current file
def writeCharLevel():
   global levelChoice
   string = levelChoice.get()
   with open(charFile, 'a') as file:
       file.write(string+"\n")
#code to both check that the character's age is a number, and then write it to the current file
def writeCharAge():
   global characterAge
   string = characterAge.get()
   if string.isdigit()== True:
      with open(charFile, 'a') as file:
          file.write(string+"\n")
   elif string == '':
      retrivedCharWrite.configure(text="Please enter an\nage")
   else:
      retrivedCharWrite.configure(text="Please enter a\nnumber for the age")
#Code to write the character's inventory and proficiencies to the current file
def writeInventory():
   global inventoryInp1
   global inventoryInp2
   global inventoryInp3
   global inventoryInp4
   global inventoryInp5
   global inventoryInp6
   global inventoryInp7
   global inventoryInp8
   global inventoryInp9
   global string
   string=''
   count=0
   inventory=[]
   inventory.append(inventoryInp1.get())
   inventory.append(inventoryInp2.get())
   inventory.append(inventoryInp3.get())
   inventory.append(inventoryInp4.get())
   inventory.append(inventoryInp5.get())
   inventory.append(inventoryInp6.get())
   inventory.append(inventoryInp7.get())
   inventory.append(inventoryInp8.get())
   inventory.append(inventoryInp9.get())
   while count < 9:
      string=string+str(inventory[count])+"\n"
      count=count+1
   with open(charFile, 'a') as file:
       file.write(string+"\n")
#Code to check if a retrieved file exists
def checkCharFile():
   global retrivedChar
   global retrivedCharWrite
   try:
       with open(retrivedChar,'r') as f:
          data1=f.read()
          data2=data1.splitlines()
          retrivedCharWrite.configure(text="Name: "+str(data2[0])+"\nAge: "+str(data2[1])+"\nClass: "+str(data2[2])+"\nRace: "+str(data2[3])+"\nLevel: "+str(data2[4])+"\nInventory:\n "+str(data2[5])+"\n"+str(data2[6])+"\n"+str(data2[7])+"\n"+str(data2[8])+"\n"+str(data2[9])+"\nProficiencies:\n"+str(data2[10])+"\n"+str(data2[11])+"\n"+str(data2[12])+"\n"+str(data2[13]))
   except IOError:
       retrivedCharWrite.config(text="File not found")
#Code to retrieve a character's data
def retrieveCharacterData():
   global characterName
   global retrivedCharWrite
   global retrivedChar
   string = characterName.get()
   retrivedChar = "Data/Char"+string+".txt"
   checkCharFile()
#Code to define how the GUI looks
def openCharacter():
    global characterName
    global characterClass
    global characterRace
    global levelChoice
    global inventoryInp1
    global inventoryInp2
    global inventoryInp3
    global inventoryInp4
    global inventoryInp5
    global inventoryInp6
    global inventoryInp7
    global inventoryInp8
    global inventoryInp9
    global characterRetrieval
    global retrivedCharWrite
    global characterAge
    root3=tk.Tk()
    root3.title("Character Data")
    F3=Frame(root3)
    F3.pack(
        ipadx=300,
        ipady=500
        )
    levels=[
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10",
       "11",
       "12",
       "13",
       "14",
       "15",
       "16",
       "17",
       "18",
       "19",
       "20",
       ]
    levelChoice = StringVar(root3)
    levelChoice.set(levels[0])
    levelDisplay = OptionMenu(root3, levelChoice, *levels)
    levelDisplay.place(x=425, y=150)
    classDis = Label(root3,text="Character Level:", font=("Courier 14"))
    classDis.place(x=275, y=150)
    characterName = Entry(root3, width= 10)
    characterName.place(x=160,y=100)
    characterAge = Entry(root3, width= 10)
    characterAge.place(x=160,y=200)
    inventoryDis = Label(root3,text="Inventory Items:", font=("Courier 14"))
    inventoryDis.place(x=30, y=300)
    inventoryInp1 = Entry(root3, width= 25)
    inventoryInp1.place(x=30,y=330)
    inventoryInp2 = Entry(root3, width= 25)
    inventoryInp2.place(x=30,y=360)
    inventoryInp3 = Entry(root3, width= 25)
    inventoryInp3.place(x=30,y=390)
    inventoryInp4 = Entry(root3, width= 25)
    inventoryInp4.place(x=30,y=420)
    inventoryInp5 = Entry(root3, width= 25)
    inventoryInp5.place(x=30,y=450)
    inventoryInp6 = Entry(root3, width= 25)
    inventoryInp6.place(x=30,y=510)
    inventoryInp7 = Entry(root3, width= 25)
    inventoryInp7.place(x=30,y=540)
    inventoryInp8 = Entry(root3, width= 25)
    inventoryInp8.place(x=30,y=570)
    inventoryInp9 = Entry(root3, width= 25)
    inventoryInp9.place(x=30,y=600)
    inventoryDis = Label(root3,text="Proficiencies: ", font=("Courier 14"))
    inventoryDis.place(x=30,y=480)
    name = Label(root3,text="Character Name:", font=("Courier 14"))
    name.place(x=30, y=100)
    age = Label(root3,text="Character Age:", font=("Courier 14"))
    age.place(x=30, y=200)
    characterClass = Entry(root3, width= 10)
    characterClass.place(x=415,y=100)
    classDis = Label(root3,text="Character Class:", font=("Courier 14"))
    classDis.place(x=275, y=100)
    characterRace = Entry(root3, width= 10)
    characterRace.place(x=160,y=150)
    nameDis = Label(root3,text="Character Race:", font=("Courier 14"))
    nameDis.place(x=30, y=150)
    createrChar = Label(root3,text="Character Data", font=("Courier 22"))
    createrChar.place(x=200, y=10)
    characterClass = Entry(root3, width= 10)
    characterClass.place(x=415,y=100)
    submitBtn = Button(root3,padx=10,pady=10,text="Save",command = createCharacter)
    submitBtn.place(x=285,y=660)
    retrieveBtn = Button(root3,padx=10,pady=10, text = "Retrieve", command = retrieveCharacterData)
    retrieveBtn.place(x=275,y=700)
    retrivedCharWrite = Label(root3,text="", font=("Courier 22"))
    retrivedCharWrite.place(x=300,y=250)
    exitBtn = Button(root3,padx=10,pady=10, text = "Exit", command = root3.destroy)
    exitBtn.place(x=290,y=740)
    root3.mainloop()
