"""
This is the code that controls the dice roller mechanic of the code
"""
from tkinter import *
import tkinter as tk
import random
#The value that is being added to the result of the die roll
global modifier
modifier = 0
#The variable that represents the result of the dice roll
global roll
roll = ''
#The variable that represents the unmodified dice roll
global rand
rand = 0
#The variable that represents the modified dice roll
global modded
modded = ''
#Display the current modifier being added to rolls
def displayModifier():
   global modifier
   string= str(modifier)
   modifierResult.configure(text="Current modifier:"+string)
#Display the most recent roll
def displayRoll():
   global roll
   string= str(roll)
   rollResult.configure(text=string)
#Determine what will be written to the GUI after the roll
def defineRoll():
   global roll
   global rand
   global modded
   roll=("Result:\nYou rolled "+str(rand)+" without modifiers\nand " + modded+" with modifiers.")
#Determine what the roll will be with the modifier
def defineModded():
   global modifier
   global roll
   global rand
   global modded
   modded = str(rand+int(modifier))
#Increase the modifier by 1
def modifierUp():
    global modifier
    modifier=modifier+1
    displayModifier()
#Decrease the modifier by 1
def modifierDown():
    global modifier
    modifier=modifier-1
    displayModifier()
#Set the modifier to 0
def modifierReset():
    global modifier
    modifier = 0
    displayModifier()
#Code to roll a four-sided dice
def rollD4():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,4))
    defineModded()
    defineRoll()
    displayRoll()
#Code to roll a six-sided dice
def rollD6():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,6))
    defineModded()
    defineRoll()
    displayRoll()
#Code to roll an eight-sided dice
def rollD8():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,8))
    defineModded()
    defineRoll()
    displayRoll()
#Code to roll a 10-sided dice
def rollD10():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,10))
    defineModded()
    defineRoll()
    displayRoll()
#Code to roll a 12-sided dice
def rollD12():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,12))
    defineModded()
    defineRoll()
    displayRoll()
#Code to roll a 20-sided dice
def rollD20():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,20))
    defineModded()
    defineRoll()
    displayRoll()
#Code to roll a 100-sided dice
def rollD100():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,100))
    defineModded()
    defineRoll()
    displayRoll()
def openRoll():
   root1=tk.Tk()
   root1.title('Dice Roller')
   F1=Frame(root1)
   F1.pack(
      ipadx=300,
      ipady=300,
      )
   global modifier
   global modifierResult
   global rollResult
   modifierResult=Label(root1,text="", font=("Courier 22"))
   modifierResult.place(x=330,y=300)
   rollResult=Label(root1,text="", font=("Courier 22"))
   rollResult.place(x=110,y=500)
   modUp = Button(root1,padx=10,pady=10, text = "Modifier+1", command = modifierUp)
   modUp.place(x=490,y=160)
   modDown = Button(root1,padx=10,pady=10, text = "Modifier-1", command = modifierDown)
   modDown.place(x=490,y=210)
   modReset = Button(root1,padx=10,pady=10, text = "Reset Modifier", command = modifierReset)
   modReset.place(x=470,y=260)
   D4 = Button(root1,padx=10,pady=10, text = "Roll d4", command = rollD4)
   D4.place(x=20,y=110)
   D6 = Button(root1,padx=10,pady=10, text = "Roll d6", command = rollD6)
   D6.place(x=20,y=155)
   D8 = Button(root1,padx=10,pady=10, text = "Roll d8", command = rollD8)
   D8.place(x=20,y=200)
   D10 = Button(root1,padx=10,pady=10, text = "Roll d10", command = rollD10)
   D10.place(x=20,y=245)
   D12 = Button(root1,padx=10,pady=10, text = "Roll d12", command = rollD12)
   D12.place(x=20,y=290)
   D20 = Button(root1,padx=10,pady=10, text = "Roll d20", command = rollD20)
   D20.place(x=20,y=335)
   D100 = Button(root1,padx=10,pady=10, text = "Roll d100", command = rollD100)
   D100.place(x=20,y=380)
   exitBtn = Button(root1,padx=10,pady=10, text = "Exit", command = root1.destroy).pack()
   L = Label(root1, text="Roll the Dice!",font=("Courier 22"))
   L.place(x=200, y=20)
   displayModifier()
   root1.mainloop()
