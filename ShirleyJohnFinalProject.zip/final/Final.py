"""
John Shirley
Professor Carver
SDEV140
Final Project Version 1

This program is designed to help people who play Dungeons and Dragons manage their characters, and any information about other players that they may need.
It also has a built-in dice roller that can help players play the game.

"""
from tkinter import *
import tkinter as tk
import random
from PIL import Image, ImageTk
import PIL.Image
from diceRoller import *
from playerData import *
from characterData import *
#=============================All Global Variables================================
#The value that is being added to the result of the die roll
global modifier
modifier = 0
#The variable that represents the result of the dice roll
global roll
roll = ''
#The variable that represents the unmodified dice roll
global rand
rand = 0
#The variable that represents the modified dice roll
global modded
modded = ''
#The variable that will be set to various user enters, then put into a file
global string
string = ''
#Whatever the name of the file currently being modded is
global currentFile
currentFile = ''
#The name that the player puts into the name box
global playerName
playerName = ''
#The age that the player chooses from a drop-down list
global ageChoice
ageChoice = ''
#The number of players that the player likes to play with. Selected from a drop-down list
global playerChoice
playerChoice = ''
#What format the player likes to play with(online, live, or both). Selected from a drop-down list
global locationChoice
locationChoice = ''
#The file with player data that the user is retrieving
global retrivedFile
retrivedFile = ''
#The input from the user that allows the system to pull up player data
global playerRetrieval
playerRetrieval = ''
#The name of the character that the user enters
global characterName
characterName = ''
#The name of the file that the character's data will be stored in
global charFile
charFile = ''
#The class of the character that the user enters
global characterClass
characterClass = ''
#The race of the character that the user enters
global characterRace
characterRace = ''
#The level of the character that the user enters
global levelChoice
levelChoice = ''
#The age of the character that the user enters
global characterAge
characterAge = ''
#The inventory slots of the character that the user enters
global inventoryInp1
inventoryInp1 = ''
global inventoryInp2
inventoryInp2 = ''
global inventoryInp3
inventoryInp3 = ''
global inventoryInp4
inventoryInp4 = ''
global inventoryInp5
inventoryInp5 = ''
global inventoryInp6
inventoryInp6 = ''
global inventoryInp7
inventoryInp7 = ''
global inventoryInp8
inventoryInp8 = ''
global inventoryInp9
inventoryInp9 = ''
#The character that the player wants to retrive
global retrivedChar
retrivedChar = ''
root=tk.Tk()
root.title('DnD Assistant')
F=Frame(root)
F.pack(
    ipadx=250,
    ipady=300,
    )
L = Label(root, text="Welcome to DnD Assistant!",font=("Courier 22"))
L.place(x=50, y=20)
roller = Button(root,padx=28,pady=18, text = "Roll Dice", command = openRoll,)
roller.place(x=370, y=100)
player = Button(root,padx=20,pady=10, text = "Enter\nPlayer Data", command = openPlayer)
player.place(x=370, y=170)
character = Button(root,padx=10,pady=10, text = "Enter\nCharacter Data", command = openCharacter)
character.place(x=370, y=240)
canvas = Canvas(root, width = 200, height = 500)      
canvas.place(x=150,y=50)
photo = PIL.Image.open('dndAssitImages/welcome.png')
logo = ImageTk.PhotoImage(photo)
img = canvas.create_image(0, 0, anchor=NW, image=logo)    
canvas2 = Canvas(root, width = 2000, height = 500)
canvas2.place(x=5,y=450)
logoTxt = Label(root, text="DnD Logo",font=("Courier 10"))
logoTxt.place(x=200,y=300)
border = ImageTk.PhotoImage(PIL.Image.open('dndAssitImages/border.png'))
img2 = canvas2.create_image(0, 0, anchor=NW, image=border)
borderTxt = Label(root, text="Fancy Border",font=("Courier 10"))
borderTxt.place(x=200,y=500)
exitBtn=Button(root,padx=10,pady=10,text="Exit",command=root.destroy)
exitBtn.place(x=225,y=550)
root.mainloop()


