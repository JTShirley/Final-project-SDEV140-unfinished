from tkinter import *
import tkinter as tk
import random
from PIL import Image, ImageTk
#=============================Dice Roller Code==============================================================
global modifier
modifier = 0
global roll
roll = ''
def displayModifier():
   global modifier
   string= str(modifier)
   modifierResult.configure(text=string)
def displayRoll():
   global roll
   string= str(roll)
   rollResult.configure(text=string)
def defineRoll():
   global roll
   global rand
   global modded
   roll=("you rolled "+str(rand)+" without modifiers\nand " + modded+" with modifiers")
def defineModded():
   global modifier
   global roll
   global rand
   global modded
   modded = str(rand+int(modifier))
def modifierUp():
    global modifier
    modifier=modifier+1
    displayModifier()
def modifierDown():
    global modifier
    modifier=modifier-1
    displayModifier()
def modifierReset():
    global modifier
    modifier = 0
    displayModifier()
def rollD4():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,4))
    defineModded()
    defineRoll()
    displayRoll()
def rollD6():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,6))
    defineModded()
    roll=("you rolled "+str(rand)+" without modifiers\nand " + modded+" with modifiers")
    displayRoll()
def rollD8():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,8))
    defineModded()
    defineRoll()
    displayRoll()
def rollD10():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,10))
    defineModded()
    defineRoll()
    displayRoll()
def rollD12():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,12))
    defineModded()
    defineRoll()
    displayRoll()
def rollD20():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,20))
    defineModded()
    defineRoll()
    displayRoll()
def rollD100():
    global modifier
    global roll
    global rand
    global modded
    rand = int(random.randint(1,100))
    defineModded()
    defineRoll()
    displayRoll()
def openRoll():
   global modifier
   root1=tk.Tk()
   root1.title('Dice Roller')
   F1=Frame(root1)
   F1.pack(
      ipadx=300,
      ipady=300,
      )
   global modifierResult
   global rollResult
   modifierResult=Label(root1,text="", font=("Courier 22 bold"))
   modifierResult.place(x=520,y=300)
   rollResult=Label(root1,text="", font=("Courier 22 bold"))
   rollResult.pack()
   modUp = Button(root1,padx=10,pady=10, text = "modifier+1", command = modifierUp)
   modUp.place(x=490,y=160)
   modDown = Button(root1,padx=10,pady=10, text = "modifier-1", command = modifierDown)
   modDown.place(x=490,y=210)
   modReset = Button(root1,padx=10,pady=10, text = "reset modifier", command = modifierReset)
   modReset.place(x=470,y=260)
   D4 = Button(root1,padx=10,pady=10, text = "roll d4", command = rollD4)
   D4.place(x=20,y=110)
   D6 = Button(root1,padx=10,pady=10, text = "roll d6", command = rollD6)
   D6.place(x=20,y=155)
   D8 = Button(root1,padx=10,pady=10, text = "roll d8", command = rollD8)
   D8.place(x=20,y=200)
   D10 = Button(root1,padx=10,pady=10, text = "roll d10", command = rollD10)
   D10.place(x=20,y=245)
   D12 = Button(root1,padx=10,pady=10, text = "roll d12", command = rollD12)
   D12.place(x=20,y=290)
   D20 = Button(root1,padx=10,pady=10, text = "roll d20", command = rollD20)
   D20.place(x=20,y=335)
   D100 = Button(root1,padx=10,pady=10, text = "roll d100", command = rollD100)
   D100.place(x=20,y=380)
   exitBtn = Button(root1,padx=10,pady=10, text = "exit", command = root1.destroy).pack()
   L = Label(root1, text="Roll the Dice!",font=("Courier 22"))
   L.place(x=175, y=20)
   displayModifier()
   root1.mainloop()
#=============================Player creater code===========================================================
global string
string = ''
def writeNew():
    global string
    global currentFile
    with open(currentFile, 'a') as file:
       file.write(string+"\n")
def newPlayer():
    global playerName
    global currentFile
    global string
    string=''
    string = playerName.get()
    print (string)
    currentFile=string+".txt"
    playerData=open(currentFile,"w")
    playerData.close()
def displayName():
   global name
   global playerName
   global string
   string=''
   string = playerName.get()
   writeNew() 
def displayAge():
   global ageChoice
   global currentFile
   global string
   string=''
   string = ageChoice.get()
   writeNew()
def displayPlayer():
   global playerChoice
   global currentFile
   global string
   string=''
   string = playerChoice.get()
   writeNew()
def displayLocation():
   global locationChoice
   global currentFile
   global string
   string=''
   string = locationChoice.get()
   writeNew()
def writePreference():
   global locationChoice
   global currentFile
   global string
   string=''
   string = locationChoice.get()
   writeNew()
   writeNew()

def save():
   newPlayer()
   displayName()
   displayAge()
   displayPlayer()
def openPlayer():
    root2=tk.Tk()
    root2.title('Player Data')
    global locationChoice
    global nameDisplay
    global ageChoice
    global ageDisplay
    global playerChoice
    global preferenceSelectOnline
    global data
    global live
    global online
    F2=Frame(root2)
    F2.pack(
        ipadx=300,
        ipady=300,
        )
    ages=[
       "1-10",
       "11-17",
       "18-25",
       "26-30",
       "31-35",
       "36-40",
       "41-45",
       "46+"
       ]
    players=[
       "1",
       "2",
       "3",
       "4",
       "5",
       "6",
       "7",
       "8",
       "9",
       "10+"
       ]
    locations=[
       "online",
       "live",
       "both"
       ]
    ageChoice = StringVar(root2)
    ageChoice.set(ages[0])
    ageDisplay = OptionMenu(F2, ageChoice, *ages)
    ageDisplay.place(x=70, y=150)
    playerChoice = StringVar(root2)
    playerChoice.set(players[0])
    playerDisplay = OptionMenu(F2, playerChoice, *players)
    playerDisplay.place(x=100,y=250)
    locationChoice = StringVar(root2)
    locationChoice.set(locations[0])
    locationDisplay = OptionMenu(F2, locationChoice, *locations)
    locationDisplay.place(x=100,y=350)
    name = Label(root2,text="Name", font=("Courier 14"))
    name.place(x=30, y=100)
    global playerName
    playerName = Entry(root2, width= 10)
    playerName.place(x=70,y=100)
    age = Label(root2,text="Age", font=("Courier 14"))
    age.place(x=30, y=150)
    players = Label(root2,text="How many players\ndo you like to play with?", font=("Courier 14"))
    players.place(x=30, y=200)
    locations = Label(root2,text="Do you prefer to play\nonline or in person?", font=("Courier 14"))
    locations.place(x=30, y=300)
    nameDisplay=Label(root2,text="", font=("Courier 22"))
    nameDisplay.place(x=175,y=100)
    ageDisplay=Label(root2,text="", font=("Courier 22"))
    ageDisplay.place(x=175,y=150)
    variable=("one-ten")
    enter = Button(root2,padx=10,pady=10, text= "save", command = save)
    enter.pack()
    exitBtn = Button(root2,padx=10,pady=10, text = "exit", command = root2.destroy).pack()
    L = Label(root2, text="Enter Player Data",font=("Courier 22"))
    L.place(x=200, y=20)
    root2.mainloop()

#=============================Character Creater Code==============================================================

def openCharacter():
    root3=tk.Tk()
    F3=Frame(root3)
    F3.pack(
        ipadx=300,
        ipady=300,
        )
    hi = Button(root3, text = "Hi", command = root3.destroy).pack()
    root3.mainloop()
def goHome():
    root=tk.Tk()
    F=Frame(root)
    F.pack(
        ipadx=300,
        ipady=300,
        )

root=tk.Tk()
root.title('DnD assistant')
F=Frame(root)
F.pack(
    ipadx=250,
    ipady=300,
    )
L = Label(root, text="Welcome to DnD assistant!",font=("Courier 22"))
L.place(x=50, y=20)
roller = Button(root,padx=10,pady=10, text = "Roll Dice", command = openRoll,)
roller.place(x=370, y=100)
player = Button(root,padx=10,pady=10, text = "Enter\nPlayer Data", command = openPlayer)
player.place(x=370, y=160)
character = Button(root,padx=10,pady=10, text = "Enter\nCharacter Data", command = openCharacter)
character.place(x=370, y=240)
canvas = Canvas(root, width = 200, height = 500)      
canvas.place(x=150,y=50)
image = ImageTk.PhotoImage(Image.open('Images/welcome.png'))
img = canvas.create_image(0, 0, anchor=NW, image=image)    
canvas2 = Canvas(root, width = 2000, height = 500)      
canvas2.place(x=5,y=450)
image2 = ImageTk.PhotoImage(Image.open('Images/border.png'))
img2 = canvas2.create_image(0, 0, anchor=NW, image=image2)
exitBtn=Button(root,padx=10,pady=10,text="exit",command=root.destroy)
exitBtn.place(x=225,y=550)
root.mainloop()


